from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._convert_impl import BoardModel

from .schemas import BGAEntry

_BGA_RE = re.compile(r"\bbga\b", re.IGNORECASE)


def _is_bga(footprint: str, part: str) -> bool:
    return bool(_BGA_RE.search(footprint) or _BGA_RE.search(part))


def extract_bga_list(board: "BoardModel") -> list[BGAEntry]:
    result: list[BGAEntry] = []
    for comp in board.components:
        if not _is_bga(comp.footprint or "", comp.part or ""):
            continue
        pin_count = len(comp.pins)
        detail = f"BGA {pin_count}pin" if pin_count else (comp.footprint or comp.part or "BGA")
        result.append(BGAEntry(label=comp.ref, detail=detail))
    return result
