from __future__ import annotations

import tempfile
from pathlib import Path

from ._convert_impl import (
    parse_txt_board,
    write_kicad,
    parse_kicad_board,
    emit_txt,
    looks_like_kicad_board_text,
    looks_like_txt_layout_text,
    BoardModel,
)


def txt_to_kicad(txt_text: str, *, stem: str = "board") -> str:
    if not (txt_text or "").strip():
        return txt_text
    if looks_like_kicad_board_text(txt_text):
        return txt_text
    with tempfile.TemporaryDirectory(prefix="txt_to_kicad_") as tmp_dir:
        p = Path(tmp_dir) / f"{stem}.txt"
        p.write_text(txt_text, encoding="utf-8")
        board = parse_txt_board(p)
        return write_kicad(board)


def kicad_to_txt(kicad_text: str, *, stem: str = "board") -> str:
    if not (kicad_text or "").strip():
        return kicad_text
    if looks_like_txt_layout_text(kicad_text):
        return kicad_text
    with tempfile.TemporaryDirectory(prefix="kicad_to_txt_") as tmp_dir:
        p = Path(tmp_dir) / f"{stem}.kicad_pcb"
        p.write_text(kicad_text, encoding="utf-8")
        board = parse_kicad_board(p)
        return emit_txt(board, donor_txt_path=None)


def parse_txt_to_board_model(txt_text: str, *, stem: str = "board") -> BoardModel:
    with tempfile.TemporaryDirectory(prefix="txt_parse_") as tmp_dir:
        p = Path(tmp_dir) / f"{stem}.txt"
        p.write_text(txt_text, encoding="utf-8")
        return parse_txt_board(p)
