from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional, Sequence

from .schemas import MissingEndpoint, MissingNetPlan


_RE_HEADER = re.compile(r"^\s*(\d+)\.\s*网络\s+(\d+)\((.*)\)\s*$")
_RE_MISSING = re.compile(r"^\s*缺失详情:\s*(.*)\s*$")
_RE_CODE = re.compile(r"^\s*补全代码:\s*$")
_RE_REF_PAD = re.compile(r"BGA\s*(?P<ref>\S+).*?焊盘\s*(?P<pad>\S+)")


def _extract_two_endpoints(detail: str) -> tuple[MissingEndpoint, MissingEndpoint]:
    re_ep1 = re.compile(
        r"位于层\s*(?P<layer1>\S+)\s*，\s*坐标\s*\(\s*(?P<x1>-?\d+(?:\.\d+)?)\s*,\s*(?P<y1>-?\d+(?:\.\d+)?)\s*\)"
    )
    m1 = re_ep1.search(detail)
    if not m1:
        raise ValueError(f"cannot find first endpoint in detail: {detail}")

    tail = detail[m1.end() :]

    re_ep2_a = re.compile(
        r"终止于\s*(?P<layer2>\S+)\s*层\s*，\s*坐标\s*\(\s*(?P<x2>-?\d+(?:\.\d+)?)\s*,\s*(?P<y2>-?\d+(?:\.\d+)?)\s*\)"
    )
    m2 = re_ep2_a.search(tail)
    if not m2:
        re_ep2_b = re.compile(
            r"另一端.*?位于层\s*(?P<layer2>\S+)\s*，\s*坐标\s*\(\s*(?P<x2>-?\d+(?:\.\d+)?)\s*,\s*(?P<y2>-?\d+(?:\.\d+)?)\s*\)"
        )
        m2 = re_ep2_b.search(tail)
    if not m2:
        re_ep2_c = re.compile(
            r"位于层\s*(?P<layer2>\S+)\s*，\s*坐标\s*\(\s*(?P<x2>-?\d+(?:\.\d+)?)\s*,\s*(?P<y2>-?\d+(?:\.\d+)?)\s*\)"
        )
        m2 = re_ep2_c.search(tail)
    if not m2:
        raise ValueError(f"cannot find second endpoint in detail: {detail}")

    ep1 = MissingEndpoint(layer=m1.group("layer1"), x=float(m1.group("x1")), y=float(m1.group("y1")))
    ep2 = MissingEndpoint(layer=m2.group("layer2"), x=float(m2.group("x2")), y=float(m2.group("y2")))
    return ep1, ep2


def _read_lines(path: Path) -> list[str]:
    return path.read_text(encoding="utf-8").splitlines()


def _collect_gold_snippet(lines: Sequence[str], start_idx: int) -> tuple[Optional[str], int]:
    buf: List[str] = []
    i = start_idx
    while i < len(lines):
        line = lines[i]
        if _RE_HEADER.match(line):
            break
        if not line.strip() and buf:
            i += 1
            break
        if line.strip():
            buf.append(line.rstrip())
        i += 1
    snippet = "\n".join(buf).strip() or None
    if snippet is not None and not snippet.endswith("\n"):
        snippet += "\n"
    return snippet, i


def parse_plan_lines(lines: Sequence[str], *, source: str = "<plan>") -> list[MissingNetPlan]:
    lines_list = list(lines)
    out: List[MissingNetPlan] = []
    i = 0
    while i < len(lines_list):
        m = _RE_HEADER.match(lines_list[i])
        if not m:
            i += 1
            continue
        index = int(m.group(1))
        net_id = int(m.group(2))
        net_name = (m.group(3) or "").strip()
        i += 1

        missing_detail = ""
        gold: Optional[str] = None

        while i < len(lines_list) and not _RE_HEADER.match(lines_list[i]):
            m_miss = _RE_MISSING.match(lines_list[i])
            if m_miss:
                missing_detail = m_miss.group(1).strip()
                i += 1
                continue
            if _RE_CODE.match(lines_list[i]):
                gold, i = _collect_gold_snippet(lines_list, i + 1)
                continue
            i += 1

        if not missing_detail:
            raise ValueError(f"Plan parse error: missing '缺失详情' for net {net_id} in {source}")

        ref = None
        pad = None
        rp = _RE_REF_PAD.search(missing_detail)
        if rp:
            ref = rp.group("ref")
            pad = rp.group("pad")

        try:
            ep1_base, ep2 = _extract_two_endpoints(missing_detail)
        except ValueError as exc:
            raise ValueError(
                "Plan parse error: cannot find two endpoints in '缺失详情' "
                f"for net {net_id} in {source}: {missing_detail}"
            ) from exc

        ep1 = MissingEndpoint(
            layer=ep1_base.layer,
            x=ep1_base.x,
            y=ep1_base.y,
            ref=ref,
            pad=pad,
        )
        out.append(
            MissingNetPlan(
                index=index,
                net_id=net_id,
                net_name=net_name,
                missing_detail=missing_detail,
                endpoints=(ep1, ep2),
                gold_kicad_snippet=gold,
            )
        )
    if not out:
        raise ValueError(f"No net plans found in {source}")
    return out


def parse_plan_text(plan_text: str, *, source: str = "<plan>") -> list[MissingNetPlan]:
    return parse_plan_lines(plan_text.splitlines(), source=source)


def parse_plan_file(plan_path: str | Path) -> list[MissingNetPlan]:
    path = Path(plan_path).expanduser().resolve()
    return parse_plan_lines(_read_lines(path), source=path.as_posix())


def summarize_plan(plans: Sequence[MissingNetPlan]) -> str:
    parts: list[str] = []
    for plan in plans:
        a, b = plan.endpoints
        parts.append(
            f"- net {plan.net_id}({plan.net_name}): "
            f"{a.layer}@({a.x:.2f},{a.y:.2f}) -> {b.layer}@({b.x:.2f},{b.y:.2f})"
        )
    return "\n".join(parts)
