from __future__ import annotations

import argparse
from pathlib import Path

from .adapters.hf_local import HFLocalChatAdapter
from .adapters.openai_compatible import OpenAICompatibleChatAdapter
from .chunker import write_context_chunk_artifacts
from .io_utils import write_json, write_text
from .prompts import default_prompt_config
from .schemas import ChunkConfig, GenerationConfig
from .service import PCBChunkService
from .token_counting import make_token_counter


def _add_common_inputs(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--plan", required=True, help="Path to *_plan.txt")
    parser.add_argument("--incomplete", required=True, help="Path to *_incomplete.kicad_pcb")
    parser.add_argument("--out-dir", required=True, help="Output directory")
    parser.add_argument("--max-context-chars", type=int, default=60000)
    parser.add_argument("--chunk-chars", type=int, default=12000)
    parser.add_argument("--max-context-tokens", type=int, default=14000)
    parser.add_argument("--chunk-tokens", type=int, default=2048)
    parser.add_argument("--radius-mm", type=float, default=6.0)
    parser.add_argument("--max-chunks", type=int, default=8)
    parser.add_argument("--max-nearby-objects", type=int, default=160)
    parser.add_argument(
        "--token-counter",
        choices=["none", "approx", "transformers"],
        default="none",
        help="Token counting backend used during chunk budgeting.",
    )
    parser.add_argument(
        "--tokenizer-model-path",
        default="",
        help="Tokenizer model path used when --token-counter=transformers.",
    )


def _chunk_config_from_args(args: argparse.Namespace) -> ChunkConfig:
    return ChunkConfig(
        max_context_chars=args.max_context_chars,
        chunk_chars=args.chunk_chars,
        max_context_tokens=args.max_context_tokens,
        chunk_tokens=args.chunk_tokens,
        radius_mm=args.radius_mm,
        max_chunks=args.max_chunks,
        max_nearby_objects=args.max_nearby_objects,
    )


def _service_from_args(args: argparse.Namespace) -> tuple[PCBChunkService, ChunkConfig]:
    chunk_config = _chunk_config_from_args(args)
    return PCBChunkService(chunk_config=chunk_config, prompt_config=default_prompt_config()), chunk_config


def cmd_build_chunks(args: argparse.Namespace) -> int:
    service, chunk_config = _service_from_args(args)
    token_counter = make_token_counter(args.token_counter, model_path=args.tokenizer_model_path)
    result = service.build_chunks_from_text(
        incomplete_board_text=Path(args.incomplete).read_text(encoding="utf-8", errors="replace"),
        plan_text=Path(args.plan).read_text(encoding="utf-8", errors="replace"),
        token_counter=token_counter,
        chunk_config=chunk_config,
    )
    write_context_chunk_artifacts(args.out_dir, result.chunks, result.stats)
    write_json(Path(args.out_dir) / "chunk_result.json", result.to_dict())
    return 0


def cmd_build_prompt(args: argparse.Namespace) -> int:
    service, chunk_config = _service_from_args(args)
    token_counter = make_token_counter(args.token_counter, model_path=args.tokenizer_model_path)
    result = service.build_prompt_from_files(
        incomplete_board_path=args.incomplete,
        plan_path=args.plan,
        token_counter=token_counter,
        chunk_config=chunk_config,
    )
    write_context_chunk_artifacts(args.out_dir, result.chunks, result.stats)
    write_json(Path(args.out_dir) / "prompt_bundle.json", result.to_dict())
    write_json(Path(args.out_dir) / "messages.json", result.messages)
    write_text(Path(args.out_dir) / "system_prompt.txt", result.prompt_bundle.system + "\n")
    write_text(Path(args.out_dir) / "user_prompt.txt", result.prompt_bundle.user)
    return 0


def cmd_generate_hf(args: argparse.Namespace) -> int:
    service, chunk_config = _service_from_args(args)
    adapter = HFLocalChatAdapter(args.model_path)
    generation_config = GenerationConfig(
        max_input_tokens=args.max_input_tokens,
        max_new_tokens=args.max_new_tokens,
    )
    result = service.generate_from_text(
        incomplete_board_text=Path(args.incomplete).read_text(encoding="utf-8", errors="replace"),
        plan_text=Path(args.plan).read_text(encoding="utf-8", errors="replace"),
        adapter=adapter,
        generation_config=generation_config,
        chunk_config=chunk_config,
    )
    write_json(Path(args.out_dir) / "generation.json", result.to_dict())
    write_text(Path(args.out_dir) / "raw_generation.txt", result.raw_text)
    write_text(Path(args.out_dir) / "normalized_code.kicad_sexpr", result.normalized_code + ("\n" if result.normalized_code else ""))
    return 0


def cmd_generate_openai(args: argparse.Namespace) -> int:
    service, chunk_config = _service_from_args(args)
    token_counter = make_token_counter(args.token_counter, model_path=args.tokenizer_model_path)
    adapter = OpenAICompatibleChatAdapter(
        base_url=args.base_url,
        model=args.model,
        api_key=args.api_key,
        token_counter=token_counter,
    )
    generation_config = GenerationConfig(
        max_input_tokens=args.max_input_tokens,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
    )
    result = service.generate_from_text(
        incomplete_board_text=Path(args.incomplete).read_text(encoding="utf-8", errors="replace"),
        plan_text=Path(args.plan).read_text(encoding="utf-8", errors="replace"),
        adapter=adapter,
        generation_config=generation_config,
        chunk_config=chunk_config,
    )
    write_json(Path(args.out_dir) / "generation.json", result.to_dict())
    write_text(Path(args.out_dir) / "raw_generation.txt", result.raw_text)
    write_text(Path(args.out_dir) / "normalized_code.kicad_sexpr", result.normalized_code + ("\n" if result.normalized_code else ""))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Independent KiCad chunking and prompt service.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p = subparsers.add_parser("build-chunks", help="Build chunk artifacts from plan + incomplete board.")
    _add_common_inputs(p)
    p.set_defaults(func=cmd_build_chunks)

    p = subparsers.add_parser("build-prompt", help="Build prompt artifacts from plan + incomplete board.")
    _add_common_inputs(p)
    p.set_defaults(func=cmd_build_prompt)

    p = subparsers.add_parser("generate-hf", help="Generate with a local HF model.")
    _add_common_inputs(p)
    p.add_argument("--model-path", required=True)
    p.add_argument("--max-input-tokens", type=int, default=28672)
    p.add_argument("--max-new-tokens", type=int, default=4096)
    p.set_defaults(func=cmd_generate_hf)

    p = subparsers.add_parser("generate-openai", help="Generate with an OpenAI-compatible HTTP endpoint.")
    _add_common_inputs(p)
    p.add_argument("--base-url", required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--api-key", default="")
    p.add_argument("--max-input-tokens", type=int, default=28672)
    p.add_argument("--max-new-tokens", type=int, default=4096)
    p.add_argument("--temperature", type=float, default=None)
    p.set_defaults(func=cmd_generate_openai)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
