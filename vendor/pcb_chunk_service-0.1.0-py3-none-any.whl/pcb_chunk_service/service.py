from __future__ import annotations

from pathlib import Path
from typing import Optional

from .adapters.base import ModelAdapter
from .bga_extractor import extract_bga_list
from .chunker import build_incomplete_board_context_chunks, render_context_chunks, write_context_chunk_artifacts
from .converter import parse_txt_to_board_model, txt_to_kicad
from .io_utils import read_text
from .plan_parser import parse_plan_file, parse_plan_text
from .postprocess import normalize_generated_code
from .prompts import build_prompt_bundle, default_prompt_config
from .schemas import (
    BGAEntry,
    ChunkBuildResult,
    ChunkConfig,
    GenerationConfig,
    GenerationResult,
    PromptBuildResult,
    PromptConfig,
    TokenCounter,
)


class PCBChunkService:
    def __init__(
        self,
        *,
        chunk_config: ChunkConfig | None = None,
        prompt_config: PromptConfig | None = None,
    ) -> None:
        self.chunk_config = chunk_config or ChunkConfig()
        self.prompt_config = prompt_config or default_prompt_config()

    def build_chunks_from_text(
        self,
        *,
        incomplete_board_text: str,
        plan_text: str,
        token_counter: TokenCounter | None = None,
        chunk_config: ChunkConfig | None = None,
    ) -> ChunkBuildResult:
        config = chunk_config or self.chunk_config
        plans = parse_plan_text(plan_text)
        chunks, stats = build_incomplete_board_context_chunks(
            incomplete_board_text,
            plans,
            max_context_chars=config.max_context_chars,
            chunk_chars=config.chunk_chars,
            max_context_tokens=config.max_context_tokens,
            chunk_tokens=config.chunk_tokens,
            radius_mm=config.radius_mm,
            max_chunks=config.max_chunks,
            max_nearby_objects=config.max_nearby_objects,
            token_counter=token_counter,
        )
        return ChunkBuildResult(
            plans=tuple(plans),
            chunks=tuple(chunks),
            context_text=render_context_chunks(chunks),
            stats=stats,
        )

    def build_prompt_from_text(
        self,
        *,
        incomplete_board_text: str,
        plan_text: str,
        token_counter: TokenCounter | None = None,
        chunk_config: ChunkConfig | None = None,
        prompt_config: PromptConfig | None = None,
    ) -> PromptBuildResult:
        chunk_result = self.build_chunks_from_text(
            incomplete_board_text=incomplete_board_text,
            plan_text=plan_text,
            token_counter=token_counter,
            chunk_config=chunk_config,
        )
        prompt_bundle = build_prompt_bundle(
            plans=chunk_result.plans,
            chunks=chunk_result.chunks,
            prompt_config=prompt_config or self.prompt_config,
        )
        return PromptBuildResult(
            plans=chunk_result.plans,
            chunks=chunk_result.chunks,
            context_text=chunk_result.context_text,
            stats=chunk_result.stats,
            prompt_bundle=prompt_bundle,
        )

    def build_prompt_from_files(
        self,
        *,
        incomplete_board_path: str | Path,
        plan_path: str | Path,
        token_counter: TokenCounter | None = None,
        chunk_config: ChunkConfig | None = None,
        prompt_config: PromptConfig | None = None,
    ) -> PromptBuildResult:
        return self.build_prompt_from_text(
            incomplete_board_text=read_text(incomplete_board_path),
            plan_text=read_text(plan_path),
            token_counter=token_counter,
            chunk_config=chunk_config,
            prompt_config=prompt_config,
        )

    def write_chunk_artifacts(self, out_dir: str | Path, result: ChunkBuildResult) -> None:
        write_context_chunk_artifacts(out_dir, result.chunks, result.stats)

    def generate_from_text(
        self,
        *,
        incomplete_board_text: str,
        plan_text: str,
        adapter: ModelAdapter,
        generation_config: GenerationConfig,
        chunk_config: ChunkConfig | None = None,
        prompt_config: PromptConfig | None = None,
    ) -> GenerationResult:
        token_counter = adapter.get_token_counter()
        prompt_result = self.build_prompt_from_text(
            incomplete_board_text=incomplete_board_text,
            plan_text=plan_text,
            token_counter=token_counter,
            chunk_config=chunk_config,
            prompt_config=prompt_config,
        )
        raw_text, meta = adapter.generate(prompt_result.prompt_bundle, generation_config)
        normalized_code = normalize_generated_code(raw_text)
        prompt_tokens = token_counter(prompt_result.prompt_bundle.system + "\n" + prompt_result.prompt_bundle.user) if token_counter else None
        output_tokens = token_counter(raw_text) if token_counter else None
        metadata = {"adapter": adapter.name, **meta}
        return GenerationResult(
            raw_text=raw_text,
            normalized_code=normalized_code,
            prompt_token_count=prompt_tokens,
            output_token_count=output_tokens,
            metadata=metadata,
        )

    def extract_bga_from_txt(self, *, qiyun_board_text: str) -> list[BGAEntry]:
        """Parse 启云方 format PCB text and return all BGA components.

        Format conversion (txt→KiCad) and BGA identification happen entirely
        inside this method and are not exposed to the caller.
        """
        board = parse_txt_to_board_model(qiyun_board_text)
        return extract_bga_list(board)
