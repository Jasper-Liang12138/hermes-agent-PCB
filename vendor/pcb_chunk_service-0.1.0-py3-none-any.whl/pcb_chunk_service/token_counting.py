from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from .schemas import TokenCounter


@dataclass(frozen=True)
class ApproxTokenCounter:
    chars_per_token: float = 4.0

    def __call__(self, text: str) -> int:
        if not text:
            return 0
        return max(1, int(math.ceil(len(text) / self.chars_per_token)))


class TransformersTokenCounter:
    def __init__(self, model_path: str) -> None:
        from transformers import AutoTokenizer

        self._tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True, use_fast=False)

    def __call__(self, text: str) -> int:
        return len(self._tokenizer.encode(text, add_special_tokens=False))


def make_token_counter(kind: str, *, model_path: str = "") -> Optional[TokenCounter]:
    normalized = (kind or "none").strip().lower()
    if normalized in {"", "none", "off"}:
        return None
    if normalized == "approx":
        return ApproxTokenCounter()
    if normalized == "transformers":
        if not model_path:
            raise ValueError("model_path is required when token_counter=transformers")
        return TransformersTokenCounter(model_path)
    raise ValueError(f"unsupported token counter kind: {kind}")
