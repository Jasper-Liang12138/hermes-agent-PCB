from __future__ import annotations

from typing import Iterable, Sequence

from .chunker import render_context_chunks
from .schemas import ContextChunk, MissingNetPlan, PromptBundle, PromptConfig


DEFAULT_SYSTEM_PROMPT = (
    "你是一名资深 PCB 走线工程师，熟悉 KiCad 的 .kicad_pcb S-expression 格式。"
    "你需要根据缺失走线描述和局部板上下文，输出可以直接回填到 KiCad 的布线对象。"
    "你的首要目标是同时满足连通性、局部可制造性与 DRC 约束。"
)


DEFAULT_DRC_RULES: tuple[str, ...] = (
    "不同 net 的铜线在同一铜层上不能交叉或重叠。",
    "每个需要补线的 BGA pad 必须有且只有一个初始 escape；不能漏接，也不能做出多个初始 escape 方向。",
    "新增走线必须真实连接到目标 pad、via 或已有同网走线，不能悬空停在附近。",
    "如果单层直连会造成交叉、拥挤或无法 escape，优先考虑合理使用 via 换层。",
    "不要修改现有对象，不要复述上下文，不要输出完整 board 或 board 级对象。",
    "输出必须尽量短，只包含完成缺失连接所需的最小 `(segment ...)` / `(via ...)` 集合。",
)


def default_prompt_config() -> PromptConfig:
    return PromptConfig(system_prompt=DEFAULT_SYSTEM_PROMPT, drc_rules=DEFAULT_DRC_RULES)


def _render_rules(rules: Sequence[str]) -> list[str]:
    return [f"- {rule}" for rule in rules]


def build_user_prompt(
    *,
    plans: Sequence[MissingNetPlan],
    board_context: str,
    prompt_config: PromptConfig,
) -> str:
    lines: list[str] = []
    lines.append("任务：补全挖空区域的布线。")
    lines.append("")
    lines.append("输入包含：")
    lines.append("- 挖空后的 KiCad .kicad_pcb 局部上下文")
    lines.append("- 缺失走线的自然语言描述（含网络 id、层、端点坐标）")
    lines.append("")
    lines.append("硬约束：")
    lines.extend(_render_rules(prompt_config.drc_rules))
    if prompt_config.extra_notes:
        lines.append("")
        lines.append("补充提醒：")
        lines.extend(_render_rules(prompt_config.extra_notes))
    lines.append("")
    lines.append("输出要求：")
    lines.append("- 只输出需要补回的 KiCad 对象。")
    lines.append("- 只允许输出 `(segment ...)` 和 `(via ...)`。")
    lines.append("- 不要输出解释性文字，不要输出 Markdown 代码块。")
    if prompt_config.forbid_board_level_objects:
        lines.append("- 严禁输出 board 级对象，例如 net/add_net/setup/footprint/zone/完整文件头尾。")
    if not prompt_config.allow_via:
        lines.append("- 当前任务禁止输出 via。")
    lines.append("")
    lines.append("挖空板上下文（只作参考，禁止复述或续写这段原文）：")
    lines.append("<<<INCOMPLETE_BOARD_CONTEXT>>>")
    lines.append(board_context)
    lines.append("<<<END_INCOMPLETE_BOARD_CONTEXT>>>")
    lines.append("")
    lines.append("缺失走线列表：")
    for plan in plans:
        a, b = plan.endpoints
        endpoint_text = (
            f"{a.layer}@({a.x:.2f},{a.y:.2f}) -> {b.layer}@({b.x:.2f},{b.y:.2f})"
        )
        lines.append(f"- 网络 {plan.net_id}({plan.net_name})：{plan.missing_detail}")
        lines.append(f"  端点摘要：{endpoint_text}")
    lines.append("")
    lines.append("再次强调：答案里只允许出现 `(segment ...)` 和 `(via ...)` 对象。")
    lines.append("现在开始输出需要补回的 KiCad 对象：")
    return "\n".join(lines).rstrip() + "\n"


def build_prompt_bundle(
    *,
    plans: Sequence[MissingNetPlan],
    chunks: Sequence[ContextChunk],
    prompt_config: PromptConfig,
) -> PromptBundle:
    board_context = render_context_chunks(chunks)
    user = build_user_prompt(plans=plans, board_context=board_context, prompt_config=prompt_config)
    return PromptBundle(system=prompt_config.system_prompt, user=user)


def build_messages(bundle: PromptBundle) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": bundle.system},
        {"role": "user", "content": bundle.user},
    ]
