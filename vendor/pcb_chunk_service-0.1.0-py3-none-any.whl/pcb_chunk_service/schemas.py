from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Optional, Sequence


TokenCounter = Callable[[str], int]


@dataclass(frozen=True)
class MissingEndpoint:
    layer: Optional[str]
    x: float
    y: float
    ref: Optional[str] = None
    pad: Optional[str] = None


@dataclass(frozen=True)
class MissingNetPlan:
    index: int
    net_id: int
    net_name: str
    missing_detail: str
    endpoints: tuple[MissingEndpoint, MissingEndpoint]
    gold_kicad_snippet: Optional[str] = None


@dataclass(frozen=True)
class ContextChunk:
    name: str
    reason: str
    object_count: int
    text: str
    token_count: Optional[int] = None

    @property
    def char_count(self) -> int:
        return len(self.text)


@dataclass(frozen=True)
class PromptBundle:
    system: str
    user: str


@dataclass(frozen=True)
class ChunkConfig:
    max_context_chars: int = 60000
    chunk_chars: int = 12000
    max_context_tokens: int = 14000
    chunk_tokens: int = 2048
    radius_mm: float = 6.0
    max_chunks: int = 8
    max_nearby_objects: int = 160


@dataclass(frozen=True)
class PromptConfig:
    system_prompt: str
    drc_rules: tuple[str, ...] = field(default_factory=tuple)
    allow_via: bool = True
    forbid_board_level_objects: bool = True
    extra_notes: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class ChunkBuildResult:
    plans: tuple[MissingNetPlan, ...]
    chunks: tuple[ContextChunk, ...]
    context_text: str
    stats: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "plans": [asdict(item) for item in self.plans],
            "chunks": [asdict(item) for item in self.chunks],
            "context_text": self.context_text,
            "stats": self.stats,
        }


@dataclass(frozen=True)
class PromptBuildResult:
    plans: tuple[MissingNetPlan, ...]
    chunks: tuple[ContextChunk, ...]
    context_text: str
    stats: dict[str, Any]
    prompt_bundle: PromptBundle

    @property
    def messages(self) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": self.prompt_bundle.system},
            {"role": "user", "content": self.prompt_bundle.user},
        ]

    def to_dict(self) -> dict[str, Any]:
        return {
            "plans": [asdict(item) for item in self.plans],
            "chunks": [asdict(item) for item in self.chunks],
            "context_text": self.context_text,
            "stats": self.stats,
            "prompt_bundle": asdict(self.prompt_bundle),
            "messages": self.messages,
        }


@dataclass(frozen=True)
class GenerationConfig:
    max_input_tokens: int = 28672
    max_new_tokens: int = 4096
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None


@dataclass(frozen=True)
class BGAEntry:
    label: str
    detail: str

    def to_dict(self) -> dict[str, str]:
        return {"label": self.label, "detail": self.detail}


@dataclass(frozen=True)
class GenerationResult:
    raw_text: str
    normalized_code: str
    prompt_token_count: Optional[int] = None
    output_token_count: Optional[int] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "raw_text": self.raw_text,
            "normalized_code": self.normalized_code,
            "prompt_token_count": self.prompt_token_count,
            "output_token_count": self.output_token_count,
            "metadata": self.metadata,
        }
