from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any, Iterable, Sequence

from .schemas import ContextChunk, MissingNetPlan, TokenCounter


class BoardObject:
    __slots__ = ("kind", "text", "start", "end", "net_ids", "layers", "bbox")

    def __init__(
        self,
        *,
        kind: str,
        text: str,
        start: int,
        end: int,
        net_ids: tuple[int, ...],
        layers: tuple[str, ...],
        bbox: tuple[float, float, float, float] | None,
    ) -> None:
        self.kind = kind
        self.text = text
        self.start = start
        self.end = end
        self.net_ids = net_ids
        self.layers = layers
        self.bbox = bbox


_RE_ROOT = re.compile(r"\(\s*kicad_pcb\b")
_RE_KIND = re.compile(r"^\s*\(\s*([^\s\)]+)")
_RE_NET = re.compile(r"\(\s*net\s+(-?\d+)(?:\s|\))")
_RE_LAYER = re.compile(r"\(\s*layer\s+([^\s\)]+)")
_RE_COORD_PAIR = re.compile(
    r"\(\s*(?:start|end|at|xy|center|mid)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)"
)

GLOBAL_KINDS = {"version", "host", "general", "page", "layers", "setup", "net_class"}
NEARBY_CONTEXT_KINDS = {"segment", "via", "arc", "module", "footprint", "zone"}


def split_top_level_objects(board_text: str) -> list[str]:
    root = _RE_ROOT.search(board_text)
    if not root:
        return []

    objects: list[str] = []
    depth = 1
    child_start: int | None = None
    in_string = False
    escaped = False
    i = root.end()
    while i < len(board_text):
        char = board_text[i]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            i += 1
            continue
        if char == '"':
            in_string = True
        elif char == "(":
            if depth == 1:
                child_start = i
            depth += 1
        elif char == ")":
            if depth == 2 and child_start is not None:
                objects.append(board_text[child_start : i + 1].strip())
                child_start = None
            depth -= 1
            if depth <= 0:
                break
        i += 1
    return objects


def _kind(text: str) -> str:
    match = _RE_KIND.match(text)
    return match.group(1).strip() if match else "unknown"


def _net_ids(text: str) -> tuple[int, ...]:
    values: list[int] = []
    seen: set[int] = set()
    for raw in _RE_NET.findall(text):
        value = int(raw)
        if value not in seen:
            values.append(value)
            seen.add(value)
    return tuple(values)


def _layers(text: str) -> tuple[str, ...]:
    values: list[str] = []
    seen: set[str] = set()
    for raw in _RE_LAYER.findall(text):
        value = raw.strip()
        if value not in seen:
            values.append(value)
            seen.add(value)
    return tuple(values)


def _bbox(text: str) -> tuple[float, float, float, float] | None:
    coords = [(float(x), float(y)) for x, y in _RE_COORD_PAIR.findall(text)]
    if not coords:
        return None
    xs = [coord[0] for coord in coords]
    ys = [coord[1] for coord in coords]
    return min(xs), min(ys), max(xs), max(ys)


def parse_board_objects(board_text: str) -> list[BoardObject]:
    objects: list[BoardObject] = []
    search_from = 0
    for text in split_top_level_objects(board_text):
        start = board_text.find(text, search_from)
        if start < 0:
            start = search_from
        end = start + len(text)
        search_from = end
        objects.append(
            BoardObject(
                kind=_kind(text),
                text=text,
                start=start,
                end=end,
                net_ids=_net_ids(text),
                layers=_layers(text),
                bbox=_bbox(text),
            )
        )
    return objects


def _plan_net_ids(plans: Sequence[MissingNetPlan]) -> set[int]:
    return {int(plan.net_id) for plan in plans}


def _plan_endpoints(plans: Sequence[MissingNetPlan]) -> list[tuple[float, float, str | None, int]]:
    endpoints: list[tuple[float, float, str | None, int]] = []
    for plan in plans:
        for endpoint in plan.endpoints:
            endpoints.append((float(endpoint.x), float(endpoint.y), endpoint.layer, int(plan.net_id)))
    return endpoints


def _bbox_near_point(
    bbox: tuple[float, float, float, float] | None,
    x: float,
    y: float,
    radius_mm: float,
) -> bool:
    if bbox is None:
        return False
    min_x, min_y, max_x, max_y = bbox
    return (
        min_x - radius_mm <= x <= max_x + radius_mm
        and min_y - radius_mm <= y <= max_y + radius_mm
    )


def _bbox_distance_to_point(
    bbox: tuple[float, float, float, float] | None,
    x: float,
    y: float,
) -> float:
    if bbox is None:
        return math.inf
    min_x, min_y, max_x, max_y = bbox
    dx = max(min_x - x, 0.0, x - max_x)
    dy = max(min_y - y, 0.0, y - max_y)
    return math.hypot(dx, dy)


def _dedupe_objects(objects: Iterable[BoardObject]) -> list[BoardObject]:
    out: list[BoardObject] = []
    seen: set[tuple[int, int]] = set()
    for obj in objects:
        key = (obj.start, obj.end)
        if key in seen:
            continue
        out.append(obj)
        seen.add(key)
    return out


def _count_tokens(text: str, token_counter: TokenCounter | None) -> int | None:
    return token_counter(text) if token_counter is not None else None


def _truncate_to_token_budget(text: str, *, token_budget: int, token_counter: TokenCounter | None) -> str:
    if token_counter is None or token_budget <= 0:
        return text
    if token_counter(text) <= token_budget:
        return text

    marker = "\n[TRUNCATED_OBJECT_FOR_CONTEXT]"
    lo = 0
    hi = len(text)
    best = ""
    while lo <= hi:
        mid = (lo + hi) // 2
        candidate = text[:mid].rstrip() + marker
        if token_counter(candidate) <= token_budget:
            best = candidate
            lo = mid + 1
        else:
            hi = mid - 1
    return best or marker.strip()


def _pack_objects(
    *,
    name_prefix: str,
    reason: str,
    objects: Sequence[BoardObject],
    chunk_chars: int,
    chunk_tokens: int = 0,
    token_counter: TokenCounter | None = None,
) -> list[ContextChunk]:
    chunks: list[ContextChunk] = []
    current: list[str] = []
    current_count = 0
    current_chars = 0
    current_tokens = 0

    def flush() -> None:
        nonlocal current, current_count, current_chars, current_tokens
        if not current:
            return
        text = "\n\n".join(current).strip()
        chunks.append(
            ContextChunk(
                name=f"{name_prefix}_{len(chunks):03d}",
                reason=reason,
                object_count=current_count,
                text=text,
                token_count=_count_tokens(text, token_counter),
            )
        )
        current = []
        current_count = 0
        current_chars = 0
        current_tokens = 0

    for obj in objects:
        text = obj.text.strip()
        if not text:
            continue
        if len(text) > chunk_chars:
            text = text[:chunk_chars].rstrip() + "\n[TRUNCATED_OBJECT_FOR_CONTEXT]"
        if chunk_tokens > 0:
            text = _truncate_to_token_budget(text, token_budget=chunk_tokens, token_counter=token_counter)
        text_tokens = _count_tokens(text, token_counter) or 0
        extra = len(text) + (2 if current else 0)
        extra_tokens = text_tokens + (1 if current else 0)
        exceeds_chars = chunk_chars > 0 and current_chars + extra > chunk_chars
        exceeds_tokens = chunk_tokens > 0 and current_tokens + extra_tokens > chunk_tokens
        if current and (exceeds_chars or exceeds_tokens):
            flush()
        current.append(text)
        current_count += 1
        current_chars += extra
        current_tokens += extra_tokens
    flush()
    return chunks


def _limit_chunks(
    chunks: Sequence[ContextChunk],
    *,
    max_context_chars: int,
    max_chunks: int,
    max_context_tokens: int = 0,
    token_counter: TokenCounter | None = None,
) -> list[ContextChunk]:
    if max_context_chars <= 0 and max_chunks <= 0 and max_context_tokens <= 0:
        return list(chunks)

    out: list[ContextChunk] = []
    total_chars = 0
    total_tokens = 0
    for chunk in chunks:
        if max_chunks > 0 and len(out) >= max_chunks:
            break
        text = chunk.text
        token_count = chunk.token_count
        if max_context_chars > 0 and total_chars + len(text) > max_context_chars:
            remaining = max_context_chars - total_chars
            if remaining < 500:
                break
            text = text[:remaining].rstrip() + "\n[TRUNCATED_CHUNK_FOR_CONTEXT]"
            token_count = _count_tokens(text, token_counter)
        if max_context_tokens > 0:
            if token_count is None:
                token_count = _count_tokens(text, token_counter)
            token_count = token_count or 0
            if total_tokens + token_count > max_context_tokens:
                remaining_tokens = max_context_tokens - total_tokens
                if remaining_tokens < 128:
                    break
                text = _truncate_to_token_budget(text, token_budget=remaining_tokens, token_counter=token_counter)
                token_count = _count_tokens(text, token_counter) or 0
        out.append(
            ContextChunk(
                name=chunk.name,
                reason=chunk.reason,
                object_count=chunk.object_count,
                text=text,
                token_count=token_count,
            )
        )
        total_chars += len(text)
        total_tokens += token_count or 0
    return out


def build_incomplete_board_context_chunks(
    board_text: str,
    plans: Sequence[MissingNetPlan],
    *,
    max_context_chars: int = 60000,
    chunk_chars: int = 12000,
    max_context_tokens: int = 14000,
    chunk_tokens: int = 2048,
    radius_mm: float = 6.0,
    max_chunks: int = 8,
    max_nearby_objects: int = 160,
    token_counter: TokenCounter | None = None,
) -> tuple[list[ContextChunk], dict[str, Any]]:
    target_net_ids = _plan_net_ids(plans)
    endpoints = _plan_endpoints(plans)
    objects = parse_board_objects(board_text)

    global_objects: list[BoardObject] = []
    edge_objects: list[BoardObject] = []
    same_net_objects: list[BoardObject] = []
    nearby_scored: list[tuple[float, BoardObject]] = []

    for obj in objects:
        if obj.kind in GLOBAL_KINDS:
            global_objects.append(obj)
            continue
        if obj.kind == "net" and obj.net_ids and obj.net_ids[0] in target_net_ids:
            global_objects.append(obj)
            continue
        if obj.kind.startswith("gr_") and "Edge.Cuts" in obj.text:
            edge_objects.append(obj)
            continue
        if obj.kind not in NEARBY_CONTEXT_KINDS:
            continue
        if target_net_ids.intersection(obj.net_ids):
            same_net_objects.append(obj)
            continue
        distances = [
            _bbox_distance_to_point(obj.bbox, x, y)
            for x, y, _layer, _net_id in endpoints
            if _bbox_near_point(obj.bbox, x, y, radius_mm)
        ]
        if distances:
            nearby_scored.append((min(distances), obj))

    nearby_objects = [
        obj for _distance, obj in sorted(nearby_scored, key=lambda item: (item[0], item[1].start))
    ][:max_nearby_objects]

    selected_chunks: list[ContextChunk] = []
    selected_chunks.extend(
        _pack_objects(
            name_prefix="global",
            reason="board header, layer/setup info, target net declarations, and Edge.Cuts",
            objects=_dedupe_objects(global_objects + edge_objects[:32]),
            chunk_chars=chunk_chars,
            chunk_tokens=chunk_tokens,
            token_counter=token_counter,
        )
    )
    selected_chunks.extend(
        _pack_objects(
            name_prefix="same_net",
            reason="existing route objects on the missing net ids",
            objects=_dedupe_objects(same_net_objects),
            chunk_chars=chunk_chars,
            chunk_tokens=chunk_tokens,
            token_counter=token_counter,
        )
    )
    selected_chunks.extend(
        _pack_objects(
            name_prefix="nearby",
            reason=f"route objects within {radius_mm:g} mm of missing endpoints",
            objects=_dedupe_objects(nearby_objects),
            chunk_chars=chunk_chars,
            chunk_tokens=chunk_tokens,
            token_counter=token_counter,
        )
    )

    limited = _limit_chunks(
        selected_chunks,
        max_context_chars=max_context_chars,
        max_context_tokens=max_context_tokens,
        max_chunks=max_chunks,
        token_counter=token_counter,
    )
    stats = {
        "target_net_ids": sorted(target_net_ids),
        "endpoint_count": len(endpoints),
        "top_level_object_count": len(objects),
        "global_object_count": len(_dedupe_objects(global_objects + edge_objects[:32])),
        "same_net_object_count": len(_dedupe_objects(same_net_objects)),
        "nearby_object_count": len(_dedupe_objects(nearby_objects)),
        "chunk_count_before_budget": len(selected_chunks),
        "chunk_count": len(limited),
        "context_chars": sum(chunk.char_count for chunk in limited),
        "context_tokens": sum(chunk.token_count or 0 for chunk in limited),
        "max_context_chars": max_context_chars,
        "max_context_tokens": max_context_tokens,
        "chunk_chars": chunk_chars,
        "chunk_tokens": chunk_tokens,
        "radius_mm": radius_mm,
        "max_chunks": max_chunks,
        "uses_gold_completion": False,
    }
    return limited, stats


def render_context_chunks(chunks: Sequence[ContextChunk]) -> str:
    lines = [
        "上下文已按 KiCad 顶层对象分块；这些内容来自 *_incomplete.kicad_pcb，不包含 plan.txt 的补全代码。",
    ]
    for index, chunk in enumerate(chunks, start=1):
        lines.append("")
        lines.append(
            f"### CHUNK {index}: {chunk.name} | {chunk.reason} | objects={chunk.object_count} | chars={chunk.char_count}"
            + (f" | tokens={chunk.token_count}" if chunk.token_count is not None else "")
        )
        lines.append(chunk.text)
    return "\n".join(lines).rstrip() + "\n"


def write_context_chunk_artifacts(
    out_dir: str | Path,
    chunks: Sequence[ContextChunk],
    stats: dict[str, Any],
) -> None:
    root = Path(out_dir)
    chunks_dir = root / "chunks"
    chunks_dir.mkdir(parents=True, exist_ok=True)
    for old in chunks_dir.glob("*.txt"):
        old.unlink()
    for index, chunk in enumerate(chunks, start=1):
        chunk_path = chunks_dir / f"{index:03d}_{chunk.name}.txt"
        chunk_path.write_text(chunk.text.rstrip() + "\n", encoding="utf-8")
    (root / "context.txt").write_text(render_context_chunks(chunks), encoding="utf-8")
    (root / "manifest.json").write_text(
        json.dumps({**stats, "chunks": [chunk.__dict__ for chunk in chunks]}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
