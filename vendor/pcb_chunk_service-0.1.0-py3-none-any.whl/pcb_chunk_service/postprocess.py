from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class ExtractedKicadObjects:
    segments: List[str]
    vias: List[str]
    other: List[str]


_RE_SEGMENT_LINE = re.compile(r"^\s*\(\s*segment\b", re.IGNORECASE)
_RE_VIA_LINE = re.compile(r"^\s*\(\s*via\b", re.IGNORECASE)


def _s_expression_balanced(text: str) -> bool:
    depth = 0
    for ch in text:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def _normalize_kicad_object(text: str) -> str:
    cleaned = text.strip()
    if not cleaned:
        return ""
    if not _s_expression_balanced(cleaned):
        raise ValueError(f"KiCad S-expression has unbalanced parentheses: {cleaned[:120]}...")
    return cleaned + "\n"


def extract_kicad_objects_from_text(model_text: str) -> ExtractedKicadObjects:
    lines = model_text.splitlines()
    segments: List[str] = []
    vias: List[str] = []
    other: List[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if _RE_SEGMENT_LINE.match(line) or _RE_VIA_LINE.match(line):
            buf = [line.rstrip()]
            i += 1
            obj_text = "\n".join(buf)
            while i < len(lines) and not _s_expression_balanced(obj_text):
                buf.append(lines[i].rstrip())
                obj_text = "\n".join(buf)
                i += 1
            if not _s_expression_balanced(obj_text):
                other.append(f"[incomplete_kicad_object]\n{obj_text}")
                continue
            normalized = _normalize_kicad_object(obj_text)
            if _RE_SEGMENT_LINE.match(line):
                segments.append(normalized)
            else:
                vias.append(normalized)
            continue
        if line.strip():
            other.append(line.rstrip())
        i += 1
    return ExtractedKicadObjects(segments=segments, vias=vias, other=other)


def normalize_generated_code(text: str) -> str:
    extracted = extract_kicad_objects_from_text(text)
    objects = extracted.segments + extracted.vias
    return "\n".join(obj.strip() for obj in objects if obj.strip()).strip()
