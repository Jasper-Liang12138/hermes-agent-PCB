from __future__ import annotations

import json
from typing import Any
from urllib import request

from .base import ModelAdapter
from ..schemas import GenerationConfig, PromptBundle, TokenCounter
from ..token_counting import ApproxTokenCounter


class OpenAICompatibleChatAdapter(ModelAdapter):
    name = "openai-compatible"

    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        api_key: str = "",
        timeout_s: int = 300,
        token_counter: TokenCounter | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout_s = timeout_s
        self._token_counter = token_counter or ApproxTokenCounter()

    def get_token_counter(self) -> TokenCounter | None:
        return self._token_counter

    def generate(self, prompt_bundle: PromptBundle, generation_config: GenerationConfig) -> tuple[str, dict[str, Any]]:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": prompt_bundle.system},
                {"role": "user", "content": prompt_bundle.user},
            ],
            "max_tokens": generation_config.max_new_tokens,
        }
        if generation_config.temperature is not None:
            payload["temperature"] = generation_config.temperature
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        req = request.Request(
            url=f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        with request.urlopen(req, timeout=self.timeout_s) as resp:
            body = json.loads(resp.read().decode("utf-8"))
        choices = body.get("choices") or []
        if not choices:
            raise RuntimeError(f"OpenAI-compatible API returned no choices: {body}")
        message = choices[0].get("message") or {}
        content = message.get("content")
        if isinstance(content, list):
            text = "".join(part.get("text", "") for part in content if isinstance(part, dict))
        else:
            text = content or ""
        usage = body.get("usage") or {}
        meta: dict[str, Any] = {
            "base_url": self.base_url,
            "model": self.model,
            "usage": usage,
            "response_id": body.get("id"),
        }
        return text, meta
