from __future__ import annotations

from typing import Any

from .base import ModelAdapter
from ..schemas import GenerationConfig, PromptBundle, TokenCounter
from ..token_counting import TransformersTokenCounter


class HFLocalChatAdapter(ModelAdapter):
    name = "hf-local"

    def __init__(self, model_path: str) -> None:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.model_path = model_path
        self._torch = torch
        self._tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True, use_fast=False)
        if self._tokenizer.pad_token is None:
            self._tokenizer.pad_token = self._tokenizer.eos_token
        self._tokenizer.padding_side = "left"
        self._token_counter = TransformersTokenCounter(model_path)
        self._model = AutoModelForCausalLM.from_pretrained(
            model_path,
            trust_remote_code=True,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            low_cpu_mem_usage=True,
        )
        self._model.eval()
        if getattr(self._model, "generation_config", None) is not None:
            for attr in ("temperature", "top_p", "top_k"):
                if hasattr(self._model.generation_config, attr):
                    setattr(self._model.generation_config, attr, None)

    def get_token_counter(self) -> TokenCounter | None:
        return self._token_counter

    def _chat_text(self, bundle: PromptBundle) -> str:
        messages = [
            {"role": "system", "content": bundle.system},
            {"role": "user", "content": bundle.user},
        ]
        try:
            return self._tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            return self._tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

    def generate(self, prompt_bundle: PromptBundle, generation_config: GenerationConfig) -> tuple[str, dict[str, Any]]:
        prompt = self._chat_text(prompt_bundle)
        inputs = self._tokenizer(
            [prompt],
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=generation_config.max_input_tokens,
        )
        input_length = inputs["input_ids"].shape[1]
        device = next(self._model.parameters()).device
        inputs = {key: value.to(device) for key, value in inputs.items()}
        with self._torch.inference_mode():
            outputs = self._model.generate(
                **inputs,
                do_sample=False,
                max_new_tokens=generation_config.max_new_tokens,
                pad_token_id=self._tokenizer.pad_token_id,
            )
        decoded = self._tokenizer.batch_decode(outputs[:, input_length:], skip_special_tokens=True)[0]
        meta: dict[str, Any] = {
            "model_path": self.model_path,
            "prompt_truncated": self._token_counter(prompt) > generation_config.max_input_tokens,
            "max_input_tokens": generation_config.max_input_tokens,
            "max_new_tokens": generation_config.max_new_tokens,
        }
        return decoded, meta
