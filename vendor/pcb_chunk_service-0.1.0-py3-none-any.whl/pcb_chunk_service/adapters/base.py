from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..schemas import GenerationConfig, PromptBundle, TokenCounter


class ModelAdapter(ABC):
    name = "model-adapter"

    def get_token_counter(self) -> TokenCounter | None:
        return None

    @abstractmethod
    def generate(self, prompt_bundle: PromptBundle, generation_config: GenerationConfig) -> tuple[str, dict[str, Any]]:
        raise NotImplementedError
